import React from 'react';
import Dashboard from './components/Dashboard';
import ETLControl from './components/ETLControl';

export default function App(){
  return (
    <div style={{padding:20}}>
      <h1>Insurecure Dashboard</h1>
      <ETLControl />
      <Dashboard />
    </div>
  );
}

import React, { useEffect, useState } from 'react';

export default function Dashboard(){
  const [top, setTop] = useState([]);
  useEffect(()=>{ fetch('/products/top').then(r=>r.json()).then(j=>setTop(j.data || [])) },[]);
  return (
    <div>
      <h2>Top Products</h2>
      <table border="1">
        <thead><tr><th>Product ID</th><th>Name</th><th>Revenue</th></tr></thead>
        <tbody>
          {top.map((p,i)=><tr key={i}><td>{p.product_id}</td><td>{p.product_name}</td><td>{p.total_revenue}</td></tr>)}
        </tbody>
      </table>
    </div>
  );
}

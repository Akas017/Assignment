import React, { useState } from 'react';

export default function ETLControl(){
  const [status, setStatus] = useState(null);
  const trigger = async () => {
    setStatus("running");
    const r = await fetch('/etl/run', {method:'POST'});
    const j = await r.json();
    setStatus(`Last run: ${j.batch_id} revenue ${j.total_revenue}`);
  }
  return (
    <div style={{marginBottom:20}}>
      <button onClick={trigger}>Run ETL</button>
      <div>{status}</div>
    </div>
  );
}

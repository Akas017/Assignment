CREATE TABLE IF NOT EXISTS products_dim (
  product_id INTEGER PRIMARY KEY,
  product_name TEXT,
  category TEXT,
  price NUMERIC,
  stock_quantity INTEGER,
  last_updated TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customers_dim (
  customer_id INTEGER PRIMARY KEY,
  name TEXT,
  email TEXT,
  signup_date DATE,
  region TEXT
);

CREATE TABLE IF NOT EXISTS sales_fact (
  transaction_id TEXT PRIMARY KEY,
  product_id INTEGER REFERENCES products_dim(product_id),
  customer_id INTEGER REFERENCES customers_dim(customer_id),
  quantity_sold INTEGER,
  sale_date DATE,
  revenue NUMERIC,
  region TEXT,
  etl_batch_id TEXT
);

CREATE TABLE IF NOT EXISTS analytics_summary (
  id SERIAL PRIMARY KEY,
  batch_id TEXT,
  metric_date DATE,
  total_revenue NUMERIC,
  total_transactions INTEGER,
  top_products JSONB,
  category_summary JSONB,
  region_summary JSONB,
  created_at TIMESTAMP DEFAULT now()
);

import redis, json, time, logging
from app.config import REDIS_HOST, REDIS_PORT, CACHE_TTL_TOP10, CACHE_TTL_CATEGORY, CACHE_TTL_REGION
logger = logging.getLogger(__name__)

r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=True)

_cache_stats = {'hits':0, 'misses':0}

def cache_get(key):
    val = r.get(key)
    if val:
        _cache_stats['hits'] += 1
        return json.loads(val)
    _cache_stats['misses'] += 1
    return None

def cache_set(key, value, ttl):
    r.set(key, json.dumps(value), ex=ttl)

def cache_stats():
    return dict(_cache_stats)

def invalidate_keys(prefix):
    for k in r.scan_iter(f"{prefix}*"):
        r.delete(k)
        logger.info(f"Invalidated cache key {k}")

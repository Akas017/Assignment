import uvicorn
from fastapi import FastAPI
from app.logging_config import setup_logging
from app.etl.pipeline import run_etl
from app.cache import cache_get, cache_set, cache_stats, invalidate_keys
from app.config import CACHE_TTL_TOP10, CACHE_TTL_CATEGORY, CACHE_TTL_REGION
from app.db import SessionLocal
import time

setup_logging()
app = FastAPI()

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/etl/run")
def trigger_etl():
    res = run_etl("sample_data/products.csv")
    invalidate_keys("top_products")
    invalidate_keys("category_summary")
    invalidate_keys("region_summary")
    return res

@app.get("/products/top")
def get_top_products():
    key = "top_products_latest"
    data = cache_get(key)
    if data:
        return {"cached": True, "data": data}
    session = SessionLocal()
    rows = session.execute("""
       SELECT product_id, product_name, SUM(revenue) as total_revenue
       FROM sales_fact
       GROUP BY product_id, product_name
       ORDER BY total_revenue DESC
       LIMIT 10
    """).fetchall()
    result = [dict(r) for r in rows]
    cache_set(key, result, CACHE_TTL_TOP10)
    return {"cached": False, "data": result}

@app.get("/analytics/category")
def analytics_category():
    key = "category_summary_latest"
    data = cache_get(key)
    if data:
        return {"cached": True, "data": data}
    session = SessionLocal()
    rows = session.execute("""
       SELECT category, SUM(revenue) as total_revenue, SUM(quantity_sold) as total_qty
       FROM sales_fact s JOIN products_dim p ON s.product_id = p.product_id
       GROUP BY category
    """).fetchall()
    res = [dict(r) for r in rows]
    cache_set(key, res, CACHE_TTL_CATEGORY)
    return {"cached": False, "data": res}

@app.get("/analytics/region")
def analytics_region():
    key = "region_summary_latest"
    data = cache_get(key)
    if data:
        return {"cached": True, "data": data}
    session = SessionLocal()
    rows = session.execute("""
       SELECT region, SUM(revenue) as total_revenue, SUM(quantity_sold) as total_qty
       FROM sales_fact
       GROUP BY region
    """).fetchall()
    res = [dict(r) for r in rows]
    cache_set(key, res, CACHE_TTL_REGION)
    return {"cached": False, "data": res}

@app.get("/cache/stats")
def get_cache_stats():
    return cache_stats()

if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)

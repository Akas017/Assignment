from app.cache import r, cache_get, cache_set, cache_stats

def test_cache_hit_miss():
    key = "test_key"
    r.delete(key)
    s = cache_get(key)
    assert s is None
    cache_set(key, {"a":1}, 1)
    v = cache_get(key)
    assert v == {"a":1}
    stats = cache_stats()
    assert 'hits' in stats and 'misses' in stats

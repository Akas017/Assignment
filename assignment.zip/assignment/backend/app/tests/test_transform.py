import pandas as pd
from app.etl.transformers import clean_products, clean_sales, enrich_sales_with_products

def test_clean_products():
    df = pd.DataFrame({'product_id':[1,1,2],'product_name':['A','A','B'],'price':['10.0','10.0','20'],'stock_quantity':[5,5,10]})
    res = clean_products(df)
    assert res.shape[0] == 2

def test_clean_sales_and_enrich():
    prod = pd.DataFrame({'product_id':[1],'product_name':['A'],'price':[10.0],'category':['X'],'stock_quantity':[100]})
    sales = pd.DataFrame({'transaction_id':['t1'],'product_id':[1],'quantity_sold':[2],'sale_date':['2025-11-07'],'customer_id':[101],'region':['North']})
    sales = clean_sales(sales)
    enriched = enrich_sales_with_products(sales, prod)
    assert 'revenue' in enriched.columns
    assert enriched['revenue'].iloc[0] == 20.0

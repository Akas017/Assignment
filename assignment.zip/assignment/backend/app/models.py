from sqlalchemy import Column, Integer, String, Numeric, Date, Text, JSON, TIMESTAMP, ForeignKey
from app.db import Base

class Product(Base):
    __tablename__ = "products_dim"
    product_id = Column(Integer, primary_key=True)
    product_name = Column(Text)
    category = Column(Text)
    price = Column(Numeric)
    stock_quantity = Column(Integer)

class Customer(Base):
    __tablename__ = "customers_dim"
    customer_id = Column(Integer, primary_key=True)
    name = Column(Text)
    email = Column(Text)
    signup_date = Column(Date)
    region = Column(Text)

class Sale(Base):
    __tablename__ = "sales_fact"
    transaction_id = Column(Text, primary_key=True)
    product_id = Column(Integer, ForeignKey("products_dim.product_id"))
    customer_id = Column(Integer, ForeignKey("customers_dim.customer_id"))
    quantity_sold = Column(Integer)
    sale_date = Column(Date)
    revenue = Column(Numeric)
    region = Column(Text)
    etl_batch_id = Column(Text)

class AnalyticsSummary(Base):
    __tablename__ = "analytics_summary"
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(Text)
    metric_date = Column(Date)
    total_revenue = Column(Numeric)
    total_transactions = Column(Integer)
    top_products = Column(JSON)
    category_summary = Column(JSON)
    region_summary = Column(JSON)

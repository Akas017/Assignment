import logging, uuid
from app.etl.extractors import extract_products_from_csv, extract_sales_from_api, extract_customers_from_db
from app.etl.transformers import clean_products, clean_sales, enrich_sales_with_products, aggregate_metrics, category_and_region_summary, top_n_products
from app.etl.loaders import upsert_products, upsert_customers, insert_sales, insert_analytics_summary
from app.db import SessionLocal
from app.config import SALES_API_URL, ETL_BATCH_ID_PREFIX
logger = logging.getLogger(__name__)

def run_etl(products_path: str, sales_api_url: str = SALES_API_URL):
    batch_id = f"{ETL_BATCH_ID_PREFIX}_{uuid.uuid4().hex[:8]}"
    logger.info(f"Starting ETL batch {batch_id}")
    session = SessionLocal()
    try:
        products_df = extract_products_from_csv(products_path)
        products_df = clean_products(products_df)
        upsert_products(session, products_df)

        sales_df = extract_sales_from_api(sales_api_url)
        sales_df = clean_sales(sales_df)

        customers_df = extract_customers_from_db(session)
        if not customers_df.empty:
            upsert_customers(session, customers_df)

        sales_enriched = enrich_sales_with_products(sales_df, products_df)
        insert_sales(session, sales_enriched, batch_id)

        daily = aggregate_metrics(sales_enriched)
        total_revenue = float(sales_enriched['revenue'].sum()) if not sales_enriched.empty else 0.0
        total_transactions = int(sales_enriched.shape[0])
        cat, reg = category_and_region_summary(sales_enriched)
        top_products = top_n_products(sales_enriched)

        insert_analytics_summary(session, batch_id, daily['sale_date'].max() if not daily.empty else None, total_revenue, total_transactions, top_products, cat, reg)
        logger.info(f"ETL batch {batch_id} finished")
        return {"batch_id": batch_id, "total_revenue": total_revenue, "total_transactions": total_transactions}
    except Exception as e:
        logger.exception("ETL failed")
        raise
    finally:
        session.close()

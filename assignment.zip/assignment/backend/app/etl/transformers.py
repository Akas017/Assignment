import pandas as pd
import logging
from datetime import datetime
logger = logging.getLogger(__name__)

def clean_products(df: pd.DataFrame):
    df = df.drop_duplicates(subset=['product_id'])
    df['product_id'] = df['product_id'].astype(int)
    df['price'] = pd.to_numeric(df['price'], errors='coerce').fillna(0)
    df['stock_quantity'] = pd.to_numeric(df['stock_quantity'], errors='coerce').fillna(0).astype(int)
    return df

def clean_sales(df: pd.DataFrame):
    df = df.drop_duplicates(subset=['transaction_id'])
    df['quantity_sold'] = pd.to_numeric(df['quantity_sold'], errors='coerce').fillna(0).astype(int)
    df['sale_date'] = pd.to_datetime(df['sale_date'], errors='coerce').dt.date
    return df

def enrich_sales_with_products(sales_df, products_df):
    df = sales_df.merge(products_df[['product_id','price','category','product_name','stock_quantity']], on='product_id', how='left')
    df['revenue'] = df['price'] * df['quantity_sold']
    return df

def aggregate_metrics(sales_df):
    daily = sales_df.groupby(['sale_date','product_id','product_name']).agg(
        revenue=('revenue','sum'),
        quantity_sold=('quantity_sold','sum')
    ).reset_index()
    return daily

def category_and_region_summary(sales_df):
    cat = sales_df.groupby('category').agg(total_revenue=('revenue','sum'), total_qty=('quantity_sold','sum')).reset_index().to_dict(orient='records')
    reg = sales_df.groupby('region').agg(total_revenue=('revenue','sum'), total_qty=('quantity_sold','sum')).reset_index().to_dict(orient='records')
    return cat, reg

def top_n_products(sales_df, n=10):
    top = sales_df.groupby(['product_id','product_name']).agg(total_revenue=('revenue','sum')).reset_index()
    top = top.sort_values('total_revenue', ascending=False).head(n)
    return top.to_dict(orient='records')

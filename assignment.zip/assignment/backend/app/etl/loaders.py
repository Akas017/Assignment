import logging, json
import pandas as pd
logger = logging.getLogger(__name__)

def upsert_products(session, products_df):
    for _, row in products_df.iterrows():
        session.execute("""
          INSERT INTO products_dim (product_id, product_name, category, price, stock_quantity, last_updated)
          VALUES (:product_id, :product_name, :category, :price, :stock_quantity, now())
          ON CONFLICT (product_id) DO UPDATE SET
            product_name = EXCLUDED.product_name,
            category = EXCLUDED.category,
            price = EXCLUDED.price,
            stock_quantity = EXCLUDED.stock_quantity,
            last_updated = now();
        """, dict(row))
    session.commit()

def upsert_customers(session, customers_df):
    for _, row in customers_df.iterrows():
        session.execute("""
          INSERT INTO customers_dim (customer_id, name, email, signup_date, region)
          VALUES (:customer_id, :name, :email, :signup_date, :region)
          ON CONFLICT (customer_id) DO UPDATE SET
            name=EXCLUDED.name, email=EXCLUDED.email, signup_date=EXCLUDED.signup_date, region=EXCLUDED.region;
        """, dict(row))
    session.commit()

def insert_sales(session, sales_df, etl_batch_id):
    for _, r in sales_df.iterrows():
        params = {
            'transaction_id': r['transaction_id'],
            'product_id': int(r['product_id']),
            'customer_id': int(r['customer_id']) if not pd.isna(r.get('customer_id')) else None,
            'quantity_sold': int(r['quantity_sold']),
            'sale_date': r['sale_date'],
            'revenue': float(r['revenue']),
            'region': r.get('region'),
            'etl_batch_id': etl_batch_id
        }
        try:
            session.execute("""
              INSERT INTO sales_fact (transaction_id, product_id, customer_id, quantity_sold, sale_date, revenue, region, etl_batch_id)
              VALUES (:transaction_id, :product_id, :customer_id, :quantity_sold, :sale_date, :revenue, :region, :etl_batch_id)
              ON CONFLICT (transaction_id) DO NOTHING;
            """, params)
        except Exception as e:
            logger.exception("Failed to insert sale %s", params['transaction_id'])
    session.commit()

def insert_analytics_summary(session, batch_id, metric_date, total_revenue, total_transactions, top_products, category_summary, region_summary):
    session.execute("""
      INSERT INTO analytics_summary (batch_id, metric_date, total_revenue, total_transactions, top_products, category_summary, region_summary)
      VALUES (:batch_id,:metric_date,:total_revenue,:total_transactions,:top_products::jsonb,:category_summary::jsonb,:region_summary::jsonb);
    """, dict(batch_id=batch_id, metric_date=metric_date, total_revenue=total_revenue, total_transactions=total_transactions, top_products=json.dumps(top_products), category_summary=json.dumps(category_summary), region_summary=json.dumps(region_summary)))
    session.commit()

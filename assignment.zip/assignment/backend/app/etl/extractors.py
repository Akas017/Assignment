import os, json, logging, requests
import pandas as pd
from datetime import datetime
logger = logging.getLogger(__name__)

def extract_products_from_csv(path: str):
    logger.info(f"Extract products CSV: {path}")
    if not os.path.exists(path):
        logger.error("Products file missing")
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    return df

def extract_sales_from_api(url: str):
    logger.info(f"Extract sales API: {url}")
    resp = requests.get(url, timeout=10)
    if resp.status_code != 200:
        logger.error(f"API error: {resp.status_code}")
        raise RuntimeError("API failure")
    data = resp.json()
    df = pd.DataFrame(data.get("transactions", []))
    return df

def extract_customers_from_db(session):
    logger.info("Extract customers from DB")
    rows = session.execute("SELECT customer_id, name, email, signup_date, region FROM customers_dim").fetchall()
    import pandas as pd
    df = pd.DataFrame(rows, columns=["customer_id","name","email","signup_date","region"])
    return df

import os
from dotenv import load_dotenv
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
CACHE_TTL_TOP10 = int(os.getenv("CACHE_TTL_TOP10", 300))
CACHE_TTL_CATEGORY = int(os.getenv("CACHE_TTL_CATEGORY", 600))
CACHE_TTL_REGION = int(os.getenv("CACHE_TTL_REGION", 900))
SALES_API_URL = os.getenv("SALES_API_URL", "http://localhost:5000/sales")
ETL_BATCH_ID_PREFIX = os.getenv("ETL_BATCH_ID_PREFIX", "etl_run")
